package com.example.socialsync

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.socialsync.R
import com.example.socialsync.databinding.ActivityEventDetailshBinding
import com.example.socialsync.databinding.ActivityPassBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.StorageReference

class PassActivity : AppCompatActivity() {
    private lateinit var event_button: Button
    private lateinit var binding : ActivityPassBinding
    private lateinit var storageRef: StorageReference
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var org: TextView
    private lateinit var event: TextView
    private lateinit var date: TextView
    private lateinit var time: TextView
    private lateinit var location: TextView
    private lateinit var price: TextView
    private var db = FirebaseFirestore.getInstance()
    val userId = FirebaseAuth.getInstance().currentUser?.uid

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pass)
        supportActionBar?.hide()
        binding = ActivityPassBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Toast.makeText(this, "Show This Pass At Event", Toast.LENGTH_SHORT).show()


        binding.backToHome.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@PassActivity, EventDetailsh::class.java)
            startActivity(intent)
        }


        org=binding.organizer
        event=binding.eventName
        date=binding.passDate
        time=binding.passTime
        location=binding.passLocation
        price=binding.ticketPrice


        // Generate QR code
        val qrCodeText = userId.toString()
        val qrCodeWidth = 500
        val qrCodeHeight = 500
        val bitmap = QRCodeGenerator.generateQRCode(qrCodeText, qrCodeWidth, qrCodeHeight)

        // Display QR code in ImageView
       var corg= intent.getStringExtra("Org")
        val cevent=intent.getStringExtra("Event")
        val cdate=intent.getStringExtra("Date")
        val ctime=intent.getStringExtra("Time")
        val clocation=intent.getStringExtra("Location")
        val cprice=intent.getStringExtra("Price")

        org.text=corg
        event.text=cevent
        date.text=cdate
        time.text=ctime
        location.text=clocation
        price.text=cprice


        val qrCodeImageView: ImageView = findViewById(R.id.qrCodeImageView)

        bitmap?.let {
            qrCodeImageView.setImageBitmap(it)
        }
    }
}
