package com.example.socialsync

data class EventData(
    val imageUrl: String ?=null,
    val eventName: String ?= null,
    val eventDate: String ?= null,
    val eventLocation: String ?= null
)
