package com.example.socialsync

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.socialsync.databinding.ActivityAllEventBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class AllEventActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAllEventBinding
    private lateinit var rButton: Button


    private lateinit var storageRef: StorageReference
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var dbref : DatabaseReference
    private lateinit var eventRecyclerview : RecyclerView
    private  lateinit var Recycleview_created_event:Recycleview_created_event
    private lateinit var createdEventData : ArrayList<EventCreatedData>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_event)
        binding = ActivityAllEventBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        rButton=binding.btnRegisteredEventC


        binding.backToHome.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@AllEventActivity, MainActivity::class.java)
            startActivity(intent)
        }

        eventRecyclerview = findViewById(R.id.recycle_view_created_event)
        val layoutManager : RecyclerView.LayoutManager = GridLayoutManager(this,2)
        eventRecyclerview!!.layoutManager = LinearLayoutManager(this)
        eventRecyclerview.setHasFixedSize(true)
        createdEventData = arrayListOf<EventCreatedData>()

        rButton.setOnClickListener {
            val intent =
                Intent(this@AllEventActivity, RegisteredActivity::class.java)
            startActivity(intent)
        }
        getUserData()

    }

    private fun getUserData() {
        storageRef = FirebaseStorage.getInstance().reference.child("EventImage")
        firebaseFirestore = FirebaseFirestore.getInstance()
        binding.recycleViewCreatedEvent.setHasFixedSize(true)
        binding.recycleViewCreatedEvent.layoutManager = LinearLayoutManager(this)

        firebaseFirestore.collection("Events")
            .get()
            .addOnSuccessListener { snapshot ->
                for (document in snapshot.documents) {
                    val imageUrl = document.getString("Event Image")
                    val eventName = document.getString("EventName")
                    val eventOwner = document.getString("Event Owner")

                    val userId = FirebaseAuth.getInstance().currentUser!!.uid

                    Log.d("Events c", "$eventName")
                    if (eventOwner.equals(userId)){
                        if (imageUrl != null && eventName != null ) {
                            createdEventData.add(EventCreatedData(imageUrl, eventName))
                        }
                    }
                }
                binding.recycleViewCreatedEvent.adapter = Recycleview_created_event(createdEventData,this)
            }
            .addOnFailureListener { exception ->
                // Handle failure
                Log.e("Firestore", "Error getting documents: ", exception)
            }
    }


    fun onItemClick(position: Int, eventName: String?) {
        // Handle item click here, for example:
        val clickedItem = createdEventData[position]
        Log.d("On Click Events Parameter", "$eventName")

        val peventName = eventName // Replace this with the actual event name

        Toast.makeText(this, "Event Details", Toast.LENGTH_SHORT).show()

        // Start a new activity or fragment here
        val intent = Intent(this@AllEventActivity, EventDetailsh::class.java)
        intent.putExtra("eventName", peventName)

        startActivity(intent)

    }
}