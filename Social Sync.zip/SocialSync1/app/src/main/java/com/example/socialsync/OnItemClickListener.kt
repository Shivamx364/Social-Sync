package com.example.socialsync

interface OnItemClickListener {
    fun onItemClick(position: Int, data: String)}
