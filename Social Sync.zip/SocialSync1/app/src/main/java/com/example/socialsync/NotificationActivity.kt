package com.example.socialsync

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.socialsync.databinding.ActivityNotificationBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class NotificationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotificationBinding
    private lateinit var storageRef: StorageReference
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var dbref : DatabaseReference
    private lateinit var notificationRecyclerview : RecyclerView
    private lateinit var notifications : ArrayList<NotificationData>
    private var db = FirebaseFirestore.getInstance()
    val userId = FirebaseAuth.getInstance().currentUser?.uid
    var notificationR = "";

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification) // Assuming your XML file is named activity_notification.xml
        binding = ActivityNotificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()


        binding.backToHome.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@NotificationActivity, MainActivity::class.java)
            startActivity(intent)
        }

        notificationRecyclerview = findViewById(R.id.recycle_view_notification)
        notificationRecyclerview.layoutManager = LinearLayoutManager(this)
        notificationRecyclerview.setHasFixedSize(true)

        notifications = arrayListOf<NotificationData>()
        getNotificationData(notificationR)
    }

    private fun getNotificationData(notificationR: String) {
        storageRef = FirebaseStorage.getInstance().reference.child("EventImage")
        firebaseFirestore = FirebaseFirestore.getInstance()
        binding.recycleViewNotification.setHasFixedSize(true)
        binding.recycleViewNotification.layoutManager = LinearLayoutManager(this)

        firebaseFirestore.collection("Events")
            .get()
            .addOnSuccessListener { snapshot ->
                for (document in snapshot.documents) {
                    val notificationC = document.getString("Notification C")
                    val notificationOwn = document.getString("Event Owner")
                    val eventName = document.getString("EventName")

                    getOwnername(eventName)

                    Log.d("Events notification", "$notificationC")
                    if (notificationC != null && notificationOwn.equals(userId)) {

                        notifications.add(NotificationData(notificationC));
                    }

                }
                Log.d("Events notifications all", "$notifications")

                binding.recycleViewNotification.adapter = RecycleView_Notification(notifications,this)
            }
            .addOnFailureListener { exception ->
                // Handle failure
                Log.e("Firestore", "Error getting documents: ", exception)
            }
    }

    private fun getOwnername(eventName: String?) {
        db.collection("Register Event")
            .whereEqualTo("Register Event Name", eventName)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    var NotificationR = document.getString("Notification R")
                    var ownerid = document.getString("Event Owner ID")

                    Log.d("Events notificationR all", "$NotificationR")

                    if (NotificationR != null && ownerid.equals(userId)) {
                        notifications.add(NotificationData(NotificationR));
                        Log.d("Events notificationR getOwnername", "$notifications")

                    }


                }
            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Something went wrong..",
                    Toast.LENGTH_SHORT
                ).show()
            }

    }


    fun onItemClick(position: Int) {
        // Handle item click here, for example:
        val clickedItem = notifications[position]
        Toast.makeText(this, "Notification", Toast.LENGTH_SHORT).show()

        // Start a new activity or fragment here
        val intent = Intent(this@NotificationActivity, NotificationActivity::class.java)
        startActivity(intent)
    }
}
