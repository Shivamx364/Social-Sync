package com.example.socialsync

data class Event(
    val imageUrl: String,
    val eventName: String,
    val eventLocation: String,
    val eventDate: String
)
