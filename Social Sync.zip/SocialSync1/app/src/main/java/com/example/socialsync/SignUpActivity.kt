package com.example.socialsync

import android.R
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.socialsync.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        firebaseAuth = FirebaseAuth.getInstance()

        val genderSpinner = binding.GenderSpinner

        // Populate the spinner with gender options
        val genderOptions = arrayOf("Male", "Female")
        val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, genderOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genderSpinner.adapter = adapter

        val genderSpinnerAdapter = CustomSpinnerAdapter(this, genderOptions)
        binding.GenderSpinner.adapter = genderSpinnerAdapter

        // Set an OnItemSelectedListener for the spinner
        genderSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parentView: AdapterView<*>?,
                selectedItemView: View?,
                position: Int,
                id: Long
            ) {
                // Handle the selected item
                val selectedLocation = genderOptions[position]
                // Do something with the selected location...
            }

            override fun onNothingSelected(parentView: AdapterView<*>?) {
                // Do nothing here if needed
            }
        }

        binding.textviewsignin.setOnClickListener {
            val intent = Intent(this@SignUpActivity, SignInActivity::class.java)
            startActivity(intent)
        }

        binding.syncpasswordInput.setOnClickListener {
            Toast.makeText(
                this@SignUpActivity,
                "Password requires 8 characters, 1 uppercase, 1 lowercase, 1 digit, and special characters (!, @, #).",
                Toast.LENGTH_SHORT
            ).show()
        }

        binding.signupBtn.setOnClickListener {
            val syncID = binding.syncidInput.text.toString()
            val syncPass = binding.syncpasswordInput.text.toString()
            val syncConfirmPass = binding.syncconfirmpasswordInput.text.toString()
            val name = binding.nameInput.text.toString()
            val age = binding.ageInput.text.toString()
            val gender = binding.GenderSpinner.selectedItem.toString()
            val count = 0

            // Check email validity first
            if (isValidEmail(syncID)) {
                // Then check other fields
                if (syncPass.isNotEmpty() && syncConfirmPass.isNotEmpty() && name.isNotEmpty() && age.isNotEmpty()) {
                    // Check if passwords match
                    if (syncPass == syncConfirmPass) {
                        firebaseAuth.createUserWithEmailAndPassword(syncID, syncPass)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val userId = FirebaseAuth.getInstance().currentUser!!.uid

                                    // Saving data into Firestore
                                    val userMap = hashMapOf(
                                        "emailid" to syncID,
                                        "password" to syncPass,
                                        "name" to name,
                                        "age" to age,
                                        "gender" to gender,
                                        "user" to userId,
                                        "userImage" to "",
                                        "registered event" to count,
                                        "Created event" to count
                                    )

                                    db.collection("user").document(userId).set(userMap)
                                        .addOnSuccessListener {
                                            Toast.makeText(
                                                this,
                                                "Data Saved Successfully!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            binding.syncidInput.text.clear()
                                            binding.syncpasswordInput.text.clear()
                                            binding.syncconfirmpasswordInput.text.clear()
                                            binding.nameInput.text.clear()
                                            binding.ageInput.text.clear()
                                        }.addOnFailureListener {
                                            Toast.makeText(
                                                this,
                                                "Data not Saved!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }

                                    Toast.makeText(this, "Sign Up Successful!", Toast.LENGTH_SHORT)
                                        .show()
                                    val intent = Intent(this, SignInActivity::class.java)
                                    startActivity(intent)
                                } else {
                                    Toast.makeText(this, "Sign Up Failed!", Toast.LENGTH_SHORT)
                                        .show()
                                }
                            }
                    } else {
                        Toast.makeText(this, "Passwords do not match!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Kindly fill all the Details", Toast.LENGTH_SHORT).show()
                }
            } else {
                binding.syncidInput.error = "Please enter a valid email address"
            }
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    class CustomSpinnerAdapter(
        context: Context,
        private val items: Array<String>,
        private val isGenderSpinner: Boolean = false
    ) :
        ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, items) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = super.getView(position, convertView, parent)
            val textView = view.findViewById<TextView>(android.R.id.text1)
            if (isGenderSpinner) {
                textView.setTextColor(
                    ContextCompat.getColor(
                        context,
                        com.example.socialsync.R.color.purple_dark
                    )
                )
            } else {
                textView.setTextColor(
                    ContextCompat.getColor(
                        context,
                        com.example.socialsync.R.color.purple_dark
                    )
                )
            }
            return view
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = super.getDropDownView(position, convertView, parent)
            val textView = view.findViewById<TextView>(android.R.id.text1)
            if (isGenderSpinner) {
                textView.setTextColor(
                    ContextCompat.getColor(
                        context,
                        com.example.socialsync.R.color.white
                    )
                )
            } else {
                textView.setTextColor(
                    ContextCompat.getColor(
                        context,
                        com.example.socialsync.R.color.white
                    )
                )
            }
            return view
        }
    }
}

