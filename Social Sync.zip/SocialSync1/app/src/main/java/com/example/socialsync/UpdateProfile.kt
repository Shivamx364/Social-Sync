package com.example.socialsync

import android.app.ProgressDialog
import android.content.Intent
import android.media.Image
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.socialsync.databinding.ActivityUpdateProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.tasks.await

class UpdateProfile : AppCompatActivity() {
    private lateinit var binding: ActivityUpdateProfileBinding
    private lateinit var imageUri: Uri
    private val STORAGE_PERMISSION_CODE = 1001

    private  lateinit var username: TextView
    private lateinit var firebaseAuth: FirebaseAuth
    private val db = FirebaseFirestore.getInstance()
    val userId = FirebaseAuth.getInstance().currentUser!!.uid



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()


        binding.backToHome.setOnClickListener {
            Toast.makeText(this, "User Profile", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@UpdateProfile, UserProfileActivity::class.java)
            startActivity(intent)
        }

        // Set click listener for eventImage
        binding.UpdateImage.setOnClickListener {
            selectImage()
//            // Check if permission is not granted
//            if (ContextCompat.checkSelfPermission(
//                    this,
//                    Manifest.permission.READ_EXTERNAL_STORAGE
//                ) != PackageManager.PERMISSION_GRANTED
//            ) {
//                // Request permission
//                ActivityCompat.requestPermissions(
//                    this,
//                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
//                    STORAGE_PERMISSION_CODE
//                )
//            } else {
//                // Permission already granted, perform your image selection logic here
//                selectImage()
//            }
        }


        binding.updateprofilebtn.setOnClickListener {
            val name = binding.Updatedname.text.toString()
            val image = binding.UpdateImage
            if (name.isNotEmpty() && image!=null)
            {
                updateUserName(name)
                uploadImage()

            }else if (name.isNotEmpty()){
                updateUserName(name)
            }else if (image!=null){
                uploadImage()
            }else{
                Toast.makeText(this@UpdateProfile, "Kindly fill Details", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@UpdateProfile, UpdateProfile::class.java)
                startActivity(intent)
            }
            val intent = Intent(this@UpdateProfile, UserProfileActivity::class.java)
            startActivity(intent)




        }



    }


    private fun updateUserName(name: String) {

        update(name,"name")
        binding.Updatedname.text.clear()


    }

    private fun update(data: String,fildName: String) {

        db.collection("user")
            .whereEqualTo("user", userId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    // Update the field you want
                    document.reference.update(fildName, data)


                        .addOnSuccessListener {
                            Log.d("Firestore", "DocumentSnapshot successfully updated!")

                        }
                        .addOnFailureListener { e ->
                            Log.w("Firestore", "Error updating document", e)
                        }

                }
            }
            .addOnFailureListener { exception ->
                Log.w("Firestore", "Error getting documents: ", exception)
            }

    }



    private fun selectImage() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent, 100)
    }

    // Handle permission request result
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, perform your image selection logic here
                selectImage()
            } else {
                // Permission denied, handle accordingly (e.g., show an explanation, disable functionality)
            }
        }
    }

    private  fun uploadImage() {
        val progressDialog = ProgressDialog(this@UpdateProfile)
        progressDialog.setMessage("image Updating...")
        progressDialog.setCancelable(false)
        progressDialog.show()

        try {
            val filename = userId
            val storageRef = FirebaseStorage.getInstance().getReference("EventImage/$filename")
            val uploadTask = storageRef.putFile(imageUri)

            // Get the download URL after the image upload task completes
            uploadTask.continueWithTask { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                storageRef.downloadUrl
            }.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val downloadUri = task.result
                    // Add the image URL to the userMap
                    downloadUri.toString()

                    // Save data to Firestore
                    GlobalScope.launch(Dispatchers.IO) {
                        update(downloadUri.toString(),"userImage")

                    }

                    // Clear UI elements
                    binding.UpdateImage.setImageURI(null)

                    Toast.makeText(this@UpdateProfile, "Uploaded successfully!!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@UpdateProfile, UserProfileActivity::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this@UpdateProfile, "Failed to get download URL", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this@UpdateProfile, "Uploaded Failed !!", Toast.LENGTH_SHORT).show()
        } finally {
            if (progressDialog.isShowing) progressDialog.dismiss()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            imageUri = data?.data!!
            binding.UpdateImage.setImageURI(imageUri)
        }
    }


}
