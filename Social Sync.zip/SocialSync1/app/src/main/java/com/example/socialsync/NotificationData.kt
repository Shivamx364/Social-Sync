package com.example.socialsync

data class NotificationData(
    val notification: String ?= null
)
