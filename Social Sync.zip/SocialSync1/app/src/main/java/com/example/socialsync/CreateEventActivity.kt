package com.example.socialsync

import android.app.DatePickerDialog
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.icu.util.Calendar
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.socialsync.databinding.ActivityCreateEventBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.*
import kotlin.collections.HashMap
import android.Manifest
import android.provider.MediaStore

class CreateEventActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCreateEventBinding
    private lateinit var imageUri: Uri
    private lateinit var tvDatePicker: EditText
    private lateinit var selectedTimeEditText: EditText
    private lateinit var selectedTimeEditText2: EditText
    private val STORAGE_PERMISSION_CODE = 1001


    private lateinit var timeSpinner: Spinner
    private lateinit var timeSpinner2: Spinner
    private lateinit var firebaseAuth: FirebaseAuth
    private val db = FirebaseFirestore.getInstance()
    var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateEventBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()


        tvDatePicker = findViewById(R.id.tvDate)
        val mycalender = Calendar.getInstance()

        val datePicker = DatePickerDialog.OnDateSetListener { _, year, month, date ->
            mycalender.set(Calendar.YEAR, year)
            mycalender.set(Calendar.MONTH, month)
            mycalender.set(Calendar.DATE, date)
            updateLabel(mycalender)
        }

        tvDatePicker.setOnClickListener {
            DatePickerDialog(
                this, datePicker, mycalender.get(Calendar.YEAR), mycalender.get(
                    Calendar.MONTH
                ), mycalender.get(Calendar.DATE)
            ).show()
        }

        // Set click listener for eventImage
        binding.eventImage.setOnClickListener {
                            selectImage()

//            // Check if permission is not granted
//            if (ContextCompat.checkSelfPermission(
//                    this,
//                    Manifest.permission.READ_EXTERNAL_STORAGE
//                ) != PackageManager.PERMISSION_GRANTED
//            ) {
//                // Request permission
//                ActivityCompat.requestPermissions(
//                    this,
//                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
//                    STORAGE_PERMISSION_CODE
//                )
//            } else {
//                // Permission already granted, perform your image selection logic here
//                selectImage()
//            }
        }

        binding.createEventBtn.setOnClickListener {
            val eventName = binding.eventNameEditText.text.toString()
            val eventState = binding.eventLocationSpinner.selectedItem.toString()
            val eventCity = binding.eventLocationSpinner.selectedItem.toString()
            val eventAddress = binding.eventAdress.text.toString()
            val eventDate = tvDatePicker.text.toString()
            val eventTime = binding.timeSpinner.selectedItem.toString()
            val eventTimeNUM=binding.selectedTimeEditText.text.toString()
            val eventTime2 = binding.timeSpinner.selectedItem.toString()
            val eventTimeNUM2=binding.selectedTimeEditText.text.toString()
            val eventUPI = binding.eventUPI.text.toString()
            val eventFee = binding.eventFeeEditText.text.toString()
            val notification = "$eventName created Successfully"
            val eventOwner = FirebaseAuth.getInstance().currentUser!!.uid
            val eventDescription = binding.eventDescriptionEditText.text.toString()

            // Validate UPI ID
            if (!isValidUpiId(eventUPI)) {
                binding.eventUPI.error = "Provide a valid UPI ID"
                return@setOnClickListener
            }

            // Saving event data into Firestore using coroutines
            GlobalScope.launch(Dispatchers.Main) {
                try {
                    val userMap = hashMapOf(
                        "EventName" to eventName,
                        "Event State" to eventState,
                        "Event City" to eventCity,
                        "Event Address" to eventAddress,
                        "Event Date" to eventDate,
                        "Event Start Time" to eventTimeNUM+" "+eventTime,
                        "Event End Time" to eventTimeNUM2+" "+eventTime2,
                        "Event UPI" to eventUPI,
                        "Event Fee" to eventFee,
                        "Event Description" to eventDescription,
                        "Notification C" to notification,
                        "Event Owner" to eventOwner
                    )

                    // Upload image in a background thread and save URL to Firestore
                    uploadImage(eventName, userMap, eventName)

                    // Clear UI elements
                    binding.eventNameEditText.text.clear()
                    binding.eventFeeEditText.text.clear()
                    binding.eventDescriptionEditText.text.clear()

                } catch (e: Exception) {
                    Toast.makeText(
                        this@CreateEventActivity,
                        "Data not Saved!",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // Populate the spinner with location options
        val locationOptions =
            arrayOf("Bihar", "Madhya Pradesh", "Jharkhand", "Uttar Pradesh")
        val locationSpinnerAdapter = CustomSpinnerAdapter(this, locationOptions)
        binding.eventLocationSpinner.adapter = locationSpinnerAdapter

        // Set an OnItemSelectedListener for the location spinner
        binding.eventLocationSpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parentView: AdapterView<*>?,
                    selectedItemView: View?,
                    position: Int,
                    id: Long
                ) {
                    // Handle the selected item (state)
                    val selectedLocation = locationOptions[position]
                    // Populate the city spinner based on the selected state
                    populateCitySpinner(selectedLocation, binding.citySpinner)
                }

                override fun onNothingSelected(parentView: AdapterView<*>?) {
                    // Do nothing here if needed
                }
            }

        // Populate the time spinner with time options
        selectedTimeEditText = findViewById(R.id.selectedTimeEditText)
        timeSpinner = findViewById(R.id.timeSpinner)

        // Create adapter for the spinner
        val timeOptions = arrayOf("AM", "PM")
        val timeSpinnerAdapter = CustomSpinnerAdapter(this, timeOptions)
        binding.timeSpinner.adapter = timeSpinnerAdapter

        // Set item selected listener for the spinner
        timeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                // Get the selected time (AM or PM)
                timeOptions[position]


            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Handle nothing selected if needed
            }
        }

        // Populate the time spinner with time options
        selectedTimeEditText2 = findViewById(R.id.selectedTimeEditText2)
        timeSpinner2 = findViewById(R.id.timeSpinner2)

        // Create adapter for the spinner
        val timeOptions2 = arrayOf("AM", "PM")
        val timeSpinnerAdapter2 = CustomSpinnerAdapter(this, timeOptions2)
        binding.timeSpinner2.adapter = timeSpinnerAdapter2

        // Set item selected listener for the spinner
        timeSpinner2.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                // Get the selected time (AM or PM)
                timeOptions2[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Handle nothing selected if needed
            }
        }

        binding.backToHome.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@CreateEventActivity, MainActivity::class.java)
            startActivity(intent)
        }
    }

    // Function to validate UPI ID
    private fun isValidUpiId(upiId: String): Boolean {
        // Implement UPI ID validation logic here
        // For example, you can use a regular expression to validate the format
        val upiRegex = Regex("^\\d+@[a-zA-Z]+\$")
        return upiRegex.matches(upiId)
    }


    // Function to populate the city spinner based on the selected state
    private fun populateCitySpinner(selectedState: String, citySpinner: Spinner) {
        // Implement logic to populate the city spinner based on the selected state
        val cities = getCitiesForState(selectedState)
        val citySpinnerAdapter = CustomSpinnerAdapter(this, cities, true)
        binding.citySpinner.adapter = citySpinnerAdapter
    }

    // Function to get cities based on the selected state
    private fun getCitiesForState(selectedState: String): Array<String> {
        // Implement this method to fetch cities for the selected state
        // Return an array containing the cities
        // You can fetch cities from a database or use predefined lists based on states
        // For demonstration purposes, I'm returning dummy data
        return when (selectedState) {
            "Bihar" -> arrayOf("Patna", "Gaya", "Bhagalpur")
            "Madhya Pradesh" -> arrayOf("Bhopal", "Indore", "Jabalpur")
            "Jharkhand" -> arrayOf("Ranchi", "Jamshedpur", "Dhanbad")
            "Uttar Pradesh" -> arrayOf("Lucknow", "Kanpur", "Agra")
            else -> arrayOf() // Empty array by default
        }
    }

    private suspend fun uploadImage(
        eventName: String,
        userMap: HashMap<String, String>,
        eventName1: String
    ) {
        val progressDialog = ProgressDialog(this@CreateEventActivity)
        progressDialog.setMessage("Event is Creating..")
        progressDialog.setCancelable(false)
        progressDialog.show()

        try {
            val filename = eventName
            val storageRef =
                FirebaseStorage.getInstance().getReference("EventImage/$filename")
            val uploadTask = storageRef.putFile(imageUri)

            // Get the download URL after the image upload task completes
            uploadTask.continueWithTask { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                storageRef.downloadUrl
            }.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val downloadUri = task.result
                    // Add the image URL to the userMap
                    userMap["Event Image"] = downloadUri.toString()

                    db.collection("Events")
                        .whereEqualTo("EventName", eventName1)
                        .get()
                        .addOnSuccessListener { documents ->
                            if (documents.isEmpty) {
                                // Event does not exist, proceed to create it
                                GlobalScope.launch(Dispatchers.IO) {
                                    try {
                                        db.collection("Events").document(eventName)
                                            .set(userMap).await()
                                        withContext(Dispatchers.Main) {
                                            Toast.makeText(
                                                this@CreateEventActivity,
                                                "Event created successfully!!",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    } catch (e: Exception) {
                                        withContext(Dispatchers.Main) {
                                            // Handle error case here, for example:
                                            Toast.makeText(
                                                this@CreateEventActivity,
                                                "Error: ${e.message}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                }
                            } else {
                                // Event already exists, display a message or perform other actions
                                Toast.makeText(
                                    this@CreateEventActivity,
                                    "Event Already Exists",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .addOnFailureListener { exception ->
                            // Handle failure
                            Log.e("Firestore", "Error getting documents: ", exception)
                        }

                    // Clear UI elements
                    binding.eventImage.setImageURI(null)
                    binding.eventNameEditText.text.clear()
                    binding.eventAdress.text.clear()
                    binding.tvDate.text.clear()
                    binding.eventUPI.text.clear()

                    val intent = Intent(this@CreateEventActivity, MainActivity::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(
                        this@CreateEventActivity,
                        "Failed to get download URL",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(
                this@CreateEventActivity,
                "Uploaded Failed !!",
                Toast.LENGTH_SHORT
            ).show()
        } finally {
            if (progressDialog.isShowing) progressDialog.dismiss()
        }
    }

    private fun selectImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, 100)
    }

    // Handle permission request result
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, perform your image selection logic here
                selectImage()
            } else {
                // Permission denied, handle accordingly (e.g., show an explanation, disable functionality)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            imageUri = data?.data!!
            binding.eventImage.setImageURI(imageUri)
        }
    }

    private fun updateLabel(myCalendar: Calendar) {
        val myFormat = "dd-MM-yyyy"
        val sdf = java.text.SimpleDateFormat(myFormat, Locale.US)
        tvDatePicker.setText(sdf.format(myCalendar.time))
    }
}

class CustomSpinnerAdapter(context: Context, private val items: Array<String>, private val isCitySpinner: Boolean = false) :
    ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent)
        val textView = view.findViewById<TextView>(android.R.id.text1)
        if (isCitySpinner) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.purple_dark))
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.purple_dark))
        }
        return view
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getDropDownView(position, convertView, parent)
        val textView = view.findViewById<TextView>(android.R.id.text1)
        if (isCitySpinner) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.white))
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.white))
        }
        return view
    }
}