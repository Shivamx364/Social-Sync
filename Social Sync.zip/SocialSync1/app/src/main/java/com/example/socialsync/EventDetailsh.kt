package com.example.socialsync

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.socialsync.databinding.ActivityEventDetailshBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class EventDetailsh : AppCompatActivity() {

    private lateinit var event_button: Button
    private lateinit var binding : ActivityEventDetailshBinding
    private val PAY_REQUEST = 1
    private lateinit var storageRef: StorageReference
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var peventName : String

    private lateinit var eventName: TextView
    private lateinit var eventTime: TextView
    var userNAme= ""



    private lateinit var eventDate: TextView
    private lateinit var location: TextView
    private lateinit var eventImagew: ImageView
    private lateinit var amt: TextView
    private lateinit var discription: TextView
    private var db = FirebaseFirestore.getInstance()
    val userId = FirebaseAuth.getInstance().currentUser?.uid


    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEventDetailshBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        event_button = binding.eventButton
        val intent = intent
        peventName = intent?.getStringExtra("eventName").toString()

        Log.d("Events Parameter", "$peventName")

        getEventData()
        checkStatus()


        binding.backToHome.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@EventDetailsh, MainActivity::class.java)
            startActivity(intent)
        }

        event_button.setOnClickListener {
            checkStatus()
            if(event_button.text == "Join Event"){
                register(userNAme)
            }else if (event_button.text == "Register"){
                registratation()
            }else if (event_button.text == "Pay for event"){
                pay()
            }else if(event_button.text == "Click For Event Pass"){
                passGenerator()
            }else{
                Toast.makeText(this, "Something went Wrong", Toast.LENGTH_SHORT).show()
            }
        }


    }

    @SuppressLint("SuspiciousIndentation")
    private fun passGenerator() {
        passDataGenerator()
        event_button.setOnClickListener {
            Toast.makeText(
                this,
                "Show This Pass At Event",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun passDataGenerator() {
        firebaseFirestore = FirebaseFirestore.getInstance()

        firebaseFirestore.collection("Events")
            .get()
            .addOnSuccessListener { snapshot ->
                for (document in snapshot.documents) {
                    val deventName = document.getString("EventName")

                    if (deventName.equals(peventName)) {
                        var dimageUrl = document.getString("Event Image")
                        val deventLocation = document.getString("Event Address")
                        val deventDate = document.getString("Event Date")
                        val deventfee = document.getString("Event Fee")
                        val deventStartTime = document.getString("Event Start Time")
                        val deventEndTime = document.getString("Event End Time")
                        val deventTime = "$deventStartTime - $deventEndTime"
                        val devenowner = document.getString("Event Owner")



                        if (dimageUrl != null && deventName != null && deventLocation != null && deventDate != null) {

                            db.collection("user")
                                .whereEqualTo("user", devenowner)
                                .get()
                                .addOnSuccessListener { documents ->
                                    for (document in documents) {
                                        val sendname = document.getString("name")
                                        val ownerId= document.getString("user")
                                        insertEventOwnerData(ownerId)


                                        //sending data for Pass
                                        val intent =
                                            Intent(this@EventDetailsh, PassActivity::class.java)
                                        intent.putExtra("Org", sendname)
                                        intent.putExtra("Event", peventName)
                                        intent.putExtra("Date", deventDate)
                                        intent.putExtra("Time", deventTime)
                                        intent.putExtra("Location", deventLocation)
                                        intent.putExtra("Price", deventfee)

                                        startActivity(intent)

                                    }
                                }.addOnFailureListener { exception ->
                                    // Handle failure
                                    Log.e("Firestore", "Error getting documents: ", exception)
                                }

                        }
                    }

                }

            }
            .addOnFailureListener { exception ->
                // Handle failure
                Log.e("Firestore", "Error getting documents: ", exception)
            }
    }

    @SuppressLint("SetTextI18n")
    private fun insertEventOwnerData(ownerId: String?) {
        val newData = hashMapOf(
            "Event Owner ID" to ownerId
        )

        db.collection("Register Event")
            .whereEqualTo("Register Event Name", peventName)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    // Add new field to the document
                    document.reference.update(newData as Map<String, Any>)
                    // Document updated successfully
                }
            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Failed",
                    Toast.LENGTH_SHORT
                ).show()
                val intent = Intent(this@EventDetailsh, EventDetailsh::class.java)
                startActivity(intent)
            }
    }



    private fun registratation() {

        db.collection("Register Event")
            .whereEqualTo("Event User", userId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    var reventName = document.getString("Register Event Name")

                    if (reventName==peventName) {
                        document.reference.update("Status of Payment", "Pay for event")
                        Toast.makeText(this, "Processing...", Toast.LENGTH_SHORT).show()
                        event_button.text="Pay for event"

                    }

                }
            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Registration Failed",
                    Toast.LENGTH_SHORT
                ).show()
                val intent =
                    Intent(this@EventDetailsh, EventDetailsh::class.java)
                startActivity(intent)

            }

    }



    @SuppressLint("SetTextI18n")
    private fun pay() {

        db.collection("Events")
            .whereEqualTo("EventName", peventName)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {


                    var reventUPI = document.getString("Event UPI")
                    var reventAmt = document.getString("Event UPI")

                    if (reventUPI != null && reventAmt!=null) {
                        if (reventUPI.isNotEmpty() && reventAmt.isNotEmpty()){
                            val upiId = reventUPI
                            val amt = reventAmt
                            PayUsingUpi(upiId, amt)
                            updatePaymentStatus()

                        } else{Toast.makeText(
                            this@EventDetailsh,
                            "Name and UPI Id are necessary",
                            Toast.LENGTH_SHORT
                        ).show()
                        }
                    }



                }

            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "UPI not FOUND ",
                    Toast.LENGTH_SHORT
                ).show()
                val intent =
                    Intent(this@EventDetailsh, EventDetailsh::class.java)
                startActivity(intent)

            }




    }

    private fun updatePaymentStatus() {
        db.collection("Register Event")
            .whereEqualTo("Event User", userId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    var reventName = document.getString("Register Event Name")

                    if (reventName==peventName) {
                        document.reference.update("Status of Payment", "Click For Event Pass")
                        Toast.makeText(this, "Payment Successful", Toast.LENGTH_SHORT).show()

                        event_button.text="Click For Event Pass"
                    }

                }
            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Registration Failed",
                    Toast.LENGTH_SHORT
                ).show()
                val intent =
                    Intent(this@EventDetailsh, EventDetailsh::class.java)
                startActivity(intent)

            }



    }

    @SuppressLint("SuspiciousIndentation")
    private fun getUserData(userNAme: String) {

        db.collection("user")
            .whereEqualTo("user", userId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    var rEventUser = document.getString("name")


                    if (rEventUser != null) {
                        userNAme ==rEventUser
                    }


                }
            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Something went wrong..",
                    Toast.LENGTH_SHORT
                ).show()
            }


    }


    @SuppressLint("SetTextI18n")
    private fun register(userNAme: String) {
        getUserData(userNAme)

        val userMap = hashMapOf(
            "Register Event Name" to peventName,
            "Status of Payment" to "Register", // Set default status to pending
            "Event User" to userId,
            "Event User Name" to this.userNAme,

            "Notification R" to "${this.userNAme} Registered for $peventName"
        )

        firebaseFirestore = FirebaseFirestore.getInstance()

        firebaseFirestore.collection("Register Event")
            .add(userMap)
            .addOnSuccessListener { documentReference ->
                // Document added successfully
                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                // You can perform any further actions here after successful addition
                Toast.makeText(this, "Register", Toast.LENGTH_SHORT).show()

            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Registration Failed",
                    Toast.LENGTH_SHORT
                ).show()
                val intent =
                    Intent(this@EventDetailsh, EventDetailsh::class.java)
                startActivity(intent)

            }

    }

    private fun checkStatus() {
        db.collection("Register Event")
            .whereEqualTo("Event User", userId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val reventName = document.getString("Register Event Name")
                    var rStatus = document.getString("Status of Payment")
                    if (reventName == peventName) {
                        event_button.text=rStatus

                    }
                }
            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Something went wrong",
                    Toast.LENGTH_SHORT
                ).show()
                val intent =
                    Intent(this@EventDetailsh, MainActivity::class.java)
                startActivity(intent)

            }

    }

    private fun PayUsingUpi(upiId: String, amt: String) {
        val uri: Uri = Uri.Builder()
            .scheme("upi").authority("pay")
            .appendQueryParameter("pa", upiId)
            .appendQueryParameter("am", amt)
            .appendQueryParameter("cu", "INR")
            .build()

        val upiIntent = Intent(Intent.ACTION_VIEW)
        upiIntent.data = uri
        val chooser = Intent.createChooser(upiIntent, "Pay")
        if (chooser.resolveActivity(packageManager) != null) {
            startActivityForResult(chooser, PAY_REQUEST)
        } else {
            Toast.makeText(this, "No UPI app found", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PAY_REQUEST) {
            if (isInternetAvailable(this@EventDetailsh)) {
                if (data == null) {
                    Toast.makeText(this, "Transaction not complete", Toast.LENGTH_SHORT).show()
                    // registrationDataUpdate() //call to update button to registered
                } else {
                    val text = data.getStringExtra("response")
                    text?.let { upiPaymentCheck(it) }
                }
            } else {
                Toast.makeText(this, "Internet connection not available", Toast.LENGTH_SHORT).show()
            }
        }
    }



    @SuppressLint("SetTextI18n")
    private fun upiPaymentCheck(data: String) {
        val str = data
        var status = ""
        val response = str.split("&").associate {
            val (key, value) = it.split("=")
            key to value
        }
        status = response["Status"] ?: ""

        if (status.equals("success", ignoreCase = true)) {
            Toast.makeText(this, "Transaction Successful", Toast.LENGTH_SHORT).show()
        } else if (status.equals("failed", ignoreCase = true)) {
            val reason = response["Reason"] ?: ""
            if (reason.equals("upi_limit_exceeded", ignoreCase = true)) {
                Toast.makeText(this, "Transaction failed: UPI limit exceeded. Please check your UPI limit set by the bank.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Transaction failed: $reason", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Transaction status unknown", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isInternetAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        connectivityManager?.let {
            val networkInfo: NetworkInfo? = it.activeNetworkInfo
            if (networkInfo != null && networkInfo.isConnected && networkInfo.isConnectedOrConnecting && networkInfo.isAvailable) {
                return true
            }
        }
        return false
    }



    private fun eventCount(callback: (Int) -> Unit) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        db.collection("user")
            .whereEqualTo("user", userId)
            .get()
            .addOnSuccessListener { documents ->
                var count = 0
                for (document in documents) {
                    var eventCount = document.getString("registered event")
                    if (eventCount != null) {
                        count += eventCount.toInt()
                    }
                }
                callback(count)
            }
            .addOnFailureListener { exception ->
                Log.w("Firestore", "Error getting documents: ", exception)
                callback(0) // Return default value in case of failure
            }
    }


    private fun updateRegisteredEventNo(count: Int) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        db.collection("user")
            .whereEqualTo("user", userId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    // Update the field you want
                    document.reference.update("registered event", count.toString())
                        .addOnSuccessListener {
                            Log.d("Firestore", "DocumentSnapshot successfully updated!")

                        }
                        .addOnFailureListener { e ->
                            Log.w("Firestore", "Error updating document", e)
                        }

                }
            }
            .addOnFailureListener { exception ->
                Log.w("Firestore", "Error getting documents: ", exception)
            }

    }

    @SuppressLint("SuspiciousIndentation")
    private fun getEventData() {
        storageRef = FirebaseStorage.getInstance().reference.child("EventImage")
        firebaseFirestore = FirebaseFirestore.getInstance()

        firebaseFirestore.collection("Events")
            .get()
            .addOnSuccessListener { snapshot ->
                for (document in snapshot.documents) {
                    val deventName = document.getString("EventName")

                    if (deventName.equals(peventName)) {
                        var dimageUrl = document.getString("Event Image")
                        val deventLocation = document.getString("Event Address")
                        val deventDate = document.getString("Event Date")
                        val deventStartTime = document.getString("Event Start Time")
                        val deventEndTime = document.getString("Event End Time")
                        val deventTime = "$deventStartTime - $deventEndTime"
                        val ddiscription = document.getString("Event Description")
                        val deventfee = document.getString("Event Fee")



                        if (deventName != null) {

                            eventName = binding.eventName
                            eventDate = binding.textViewDate
                            location = binding.textViewLocation
                            discription = binding.discription
                            eventImagew = binding.eventImage
                            amt = binding.eventFee
                            eventTime=binding.textViewTimeValue



                            eventDate.text = deventDate
                            eventName.text = deventName
                            location.text = deventLocation
                            discription.text = ddiscription
                            amt.text = deventfee
                            eventTime.text=deventTime
                            // Load the image from the URL using Glide
                            Glide.with(this)
                                .load(dimageUrl) // dimageUrl is the URL of the image
                                .into(eventImagew)

                        }
                    }

                }

            }
            .addOnFailureListener { exception ->
                // Handle failure
                Log.e("Firestore", "Error getting documents: ", exception)
            }
    }
}