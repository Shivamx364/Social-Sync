package com.example.socialsync;

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

public class Recycleview_created_event(private val createdEventData: ArrayList<EventCreatedData>, private val listener: AllEventActivity) :
        RecyclerView.Adapter<Recycleview_created_event.MyViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
                val itemView = LayoutInflater.from(parent.context).inflate(
                        R.layout.activity_recycleview_created_event,
                        parent, false
                )

                return MyViewHolder(itemView)
        }

        override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
                val currentitem = createdEventData[position]

                Picasso.get().load(currentitem.imageUrl).into(holder.eventImage)
                holder.eventName.text = currentitem.eventName

                holder.itemView.setOnClickListener {
                        listener.onItemClick(position,currentitem.eventName)
                        }


        }

        override fun getItemCount(): Int {
                return createdEventData.size
        }

        inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

                val eventName: TextView = itemView.findViewById(R.id.eventNameC)
                val eventImage: ImageView = itemView.findViewById(R.id.eventimageC)



        }
}