package com.example.socialsync

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import com.example.socialsync.databinding.ActivityUserProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import android.widget.TextView
import com.bumptech.glide.Glide


class UserProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserProfileBinding
    private lateinit var emailId: TextView
    private lateinit var gender: TextView
    private lateinit var age: TextView
    private lateinit var name: TextView
    private lateinit var profileImage: ImageView
    private lateinit var firebaseAuth: FirebaseAuth

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)
        supportActionBar?.hide()
        binding = ActivityUserProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        emailId = binding.displayemail
        name = binding.profilename
        gender = binding.displaygender
        age = binding.displayage
        profileImage = binding.profileImage

        firebaseAuth = FirebaseAuth.getInstance()
        val userId = firebaseAuth.currentUser?.uid
        userId?.let { uid ->
            val docRef = db.collection("user").document(uid)
            docRef.get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        val demail = document.getString("emailid")
                        val dgen = document.getString("gender")
                        val dage = document.getString("age")
                        val dname= document.getString("name")
                        val dimage = document.getString("userImage")


                        emailId.text = demail
                        gender.text = dgen
                        age.text = dage
                        name.text = dname
                        Glide.with(this)
                            .load(dimage) // dimageUrl is the URL of the image
                            .into(profileImage)
                        Toast.makeText(this, "Data Found", Toast.LENGTH_SHORT).show()
                        Log.d(TAG, "DocumentSnapshot data: ${document.data}")
                    }
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Data Not Found", Toast.LENGTH_SHORT).show()
                    Log.d(TAG, "get failed with ", exception)
                }
        }


        binding.backToHome.setOnClickListener {
            Toast.makeText(this,"Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@UserProfileActivity, MainActivity::class.java)
            startActivity(intent)
        }

        binding.update.setOnClickListener {
            Toast.makeText(this,"Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@UserProfileActivity, UpdateProfile::class.java)
            startActivity(intent)
        }

        binding.signoutBtn.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            Toast.makeText(this,"Sign Out Successful!", Toast.LENGTH_SHORT).show()
            Log.d("UserProfileActivity", "Sign out button clicked.")
            val intent = Intent(this@UserProfileActivity, SignInActivity::class.java)
            startActivity(intent)
        }

    }
}
