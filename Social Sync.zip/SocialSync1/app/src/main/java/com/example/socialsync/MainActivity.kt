package com.example.socialsync

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.socialsync.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.util.Locale
import com.google.zxing.integration.android.IntentIntegrator

class MainActivity : AppCompatActivity() , LocationListener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var locationManager: LocationManager
    private lateinit var tvCity: TextView
    private lateinit var eventSearch: String
    private var isSearchSelected: Boolean = false // Assuming you have a variable to track whether search is selected


    private lateinit var tvState: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var storageRef: StorageReference
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var dbref : DatabaseReference
    private lateinit var eventRecyclerview : RecyclerView
    private lateinit var eventDetails : ArrayList<EventData>
    private lateinit var profileImage: ImageView
    private lateinit var scanButton: ImageView
    private lateinit var firebaseAuth: FirebaseAuth
    private val db = FirebaseFirestore.getInstance()
    private var locationFilter =""


    @SuppressLint("MissingInflatedId", "NotifyDataSetChanged", "WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Use view binding to set the content view
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()


        eventRecyclerview = findViewById(R.id.recycler_view)
        eventRecyclerview.layoutManager = LinearLayoutManager(this)
        eventRecyclerview.setHasFixedSize(true)

        eventDetails = arrayListOf<EventData>()

        binding.textView5.setOnClickListener {
            eventSearch= binding.textView5.text.toString()

            if (eventSearch.isNotEmpty()){
                searchBar(eventSearch)
            }
            else{
                Toast.makeText(this, "Search Event Name to Search", Toast.LENGTH_SHORT).show()

            }

        }

        // Check if search is not selected and then call getUserData
        if (!isSearchSelected) {
            getUserData()
        }


        profileImage = binding.userprofile

        firebaseAuth = FirebaseAuth.getInstance()
        val userId = firebaseAuth.currentUser?.uid
        userId?.let { uid ->
            val docRef = db.collection("user").document(uid)
            docRef.get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        val dimage = document.getString("userImage")

                        Glide.with(this)
                            .load(dimage) // dimageUrl is the URL of the image
                            .into(profileImage)
                        Log.d(ContentValues.TAG, "DocumentSnapshot data: ${document.data}")
                    }
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Data Not Found", Toast.LENGTH_SHORT).show()
                    Log.d(ContentValues.TAG, "get failed with ", exception)
                }
        }



        binding.createevents.setOnClickListener {
            Toast.makeText(this, "Create Event", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, CreateEventActivity::class.java)
            startActivity(intent)
        }

        binding.events.setOnClickListener {
            Toast.makeText(this, "All Event", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, AllEventActivity::class.java)
            startActivity(intent)
        }

        binding.home.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, MainActivity::class.java)
            startActivity(intent)
        }


        binding.notification1.setOnClickListener {
            Toast.makeText(this, "Notification", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, NotificationActivity::class.java)
            startActivity(intent)
        }

        binding.recyclerView.setOnClickListener {
            Toast.makeText(this, "Event Details", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, EventDetailsh::class.java)
            startActivity(intent)
        }

        binding.qrscaner.setOnClickListener {
            val intent = Intent(this@MainActivity, QrScannerActivity::class.java)
            startActivity(intent)
        }



        binding.userprofile.setOnClickListener {
            Toast.makeText(this, "Profile View", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, UserProfileActivity::class.java)
            startActivity(intent)
        }

        //location
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
            && ActivityCompat.checkSelfPermission(
                applicationContext,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ), 101
            )
        }

        tvCity = findViewById(R.id.txtcity)
        tvState = findViewById(R.id.txtstate)


        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        locationEnabled()
        getLocation()


        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        scanButton = binding.qrscaner
        scanButton.setOnClickListener {
            // Initialize the QR code scanner
            val integrator = IntentIntegrator(this)
            integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
            integrator.setPrompt("Scan a QR code")
            integrator.setCameraId(0) // Use the rear camera
            integrator.setBeepEnabled(false) // Disable beep sound
            integrator.setBarcodeImageEnabled(false) // Disable saving scanned images
            integrator.initiateScan()
        }



    }

    private fun searchBar(eventSearch: String) {
        getSearchData(eventSearch)

    }

    private fun getSearchData(eventSearch: String) {
        storageRef = FirebaseStorage.getInstance().reference.child("EventImage")
        firebaseFirestore = FirebaseFirestore.getInstance()
        binding.recyclerView.setHasFixedSize(true)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        firebaseFirestore.collection("Events")
            .get()
            .addOnSuccessListener { snapshot ->
                eventDetails.clear();

                for (document in snapshot.documents) {
                    val imageUrl = document.getString("Event Image")
                    val eventName = document.getString("EventName")
                    val eventLocation = document.getString("Event State")
                    val eventDate = document.getString("Event Date")


                    Log.d("Events", "$eventName")

                    if (eventLocation.equals(locationFilter) && eventName.equals(eventSearch)){
                        isSearchSelected = true

                        if (imageUrl != null && eventName != null && eventLocation != null && eventDate != null) {
                            eventDetails.add(EventData(imageUrl, eventName, eventDate, eventLocation))
                        }
                    }else if(eventSearch.isEmpty() || eventName.equals(eventSearch)) {
                        Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@MainActivity, MainActivity::class.java)
                        startActivity(intent)
                    }
                }

                binding.recyclerView.adapter = Recycler_View_Adapter(eventDetails,this)
            }
            .addOnFailureListener { exception ->
                // Handle failure
                Log.e("Firestore", "Error getting documents: ", exception)
            }
    }

    private fun getUserData() {
        storageRef = FirebaseStorage.getInstance().reference.child("EventImage")
        firebaseFirestore = FirebaseFirestore.getInstance()
        binding.recyclerView.setHasFixedSize(true)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        firebaseFirestore.collection("Events")
            .get()
            .addOnSuccessListener { snapshot ->
                for (document in snapshot.documents) {
                    val imageUrl = document.getString("Event Image")
                    val eventName = document.getString("EventName")
                    val eventLocation = document.getString("Event State")
                    val eventDate = document.getString("Event Date")


                    Log.d("Events", "$eventName")
                    if (eventLocation.equals(locationFilter)){
                        if (imageUrl != null && eventName != null && eventLocation != null && eventDate != null) {
                            eventDetails.add(EventData(imageUrl, eventName, eventDate, eventLocation))
                        }
                    }
                }

                binding.recyclerView.adapter = Recycler_View_Adapter(eventDetails,this)
            }
            .addOnFailureListener { exception ->
                // Handle failure
                Log.e("Firestore", "Error getting documents: ", exception)
            }
    }


    private fun locationEnabled() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var gpsEnabled = false
        var networkEnabled = false
        try {
            gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            networkEnabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (!gpsEnabled && !networkEnabled) {
            AlertDialog.Builder(this)
                .setTitle("Enable GPS Service")
                .setMessage("We need your GPS location to show Near Places around you.")
                .setCancelable(false)
                .setPositiveButton(
                    "Enable"
                ) { paramDialogInterface: DialogInterface?, paramInt: Int ->
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun getLocation() {
        try {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            locationManager.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER,
                500,
                5f,
                this
            )
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    override fun onLocationChanged(location: Location) {
        try {
            val geocoder = Geocoder(applicationContext, Locale.getDefault())
            val addresses: List<Address> =
                geocoder.getFromLocation(location.latitude, location.longitude, 1) as List<Address>

            tvCity.text = addresses[0].locality
            tvState.text = addresses[0].adminArea
            locationFilter=addresses[0].adminArea



        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    fun onItemClick(position: Int, eventName: String?) {
        // Handle item click here, for example:
        val clickedItem = eventDetails[position]
        Log.d("On Click Events Parameter", "$eventName")

        val peventName = eventName // Replace this with the actual event name

        Toast.makeText(this, "Event Details", Toast.LENGTH_SHORT).show()

        // Start a new activity or fragment here
        val intent = Intent(this@MainActivity, EventDetailsh::class.java)
        intent.putExtra("eventName", peventName)

        startActivity(intent)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents != null) {
                // Launch the destination activity and pass the scanned data
                val intent = Intent(this, QrScannerActivity::class.java)
                intent.putExtra("qr_data", result.contents)
                intent.putExtra("qr_data", result.contents)

                startActivity(intent)
            }
        }
    }






    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onProviderEnabled(provider: String) {}

    override fun onProviderDisabled(provider: String) {}

}

