package com.example.socialsync

data class EventCreatedData(
    val imageUrl: String ?=null,
    val eventName: String ?= null
)
