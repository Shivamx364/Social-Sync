package com.example.socialsync

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class Recycler_View_Adapter(private val eventDetails: ArrayList<EventData>, private val listener: MainActivity) :
    RecyclerView.Adapter<Recycler_View_Adapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.recycler_view_row,
            parent, false
        )

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentitem = eventDetails[position]
        Picasso.get().load(currentitem.imageUrl).into(holder.eventImage)
        holder.eventName.text = currentitem.eventName
        holder.eventDate.text = currentitem.eventDate
        holder.eventLocation.text = currentitem.eventLocation

        holder.itemView.setOnClickListener {
            listener.onItemClick(position,currentitem.eventName)
        }
    }

    override fun getItemCount(): Int {
        return eventDetails.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val eventImage: ImageView = itemView.findViewById(R.id.eventImage1)
        val eventName: TextView = itemView.findViewById(R.id.event_name)
        val eventDate: TextView = itemView.findViewById(R.id.text_view_date_value)
        val eventLocation: TextView = itemView.findViewById(R.id.text_view_location)


            }
        }
