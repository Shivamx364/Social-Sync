package com.example.socialsync

// DestinationActivity.kt
import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.socialsync.databinding.ActivityQrScannerBinding
import com.example.socialsync.databinding.ActivityUserProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class QrScannerActivity : AppCompatActivity() {


    private lateinit var binding: ActivityQrScannerBinding
    private lateinit var name: TextView




    private lateinit var profileImage: ImageView
    private lateinit var firebaseAuth: FirebaseAuth

    private val db = FirebaseFirestore.getInstance()



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_scanner)
        supportActionBar?.hide()
        binding = ActivityQrScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileImage=binding.profileImage
        name=binding.profilename


        binding.backToHome.setOnClickListener {
            Toast.makeText(this,"Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@QrScannerActivity, MainActivity::class.java)
            startActivity(intent)
        }

        // Retrieve the scanned data from the intent
        val qrData = intent.getStringExtra("qr_data")


        qrCheck(qrData)
    }

    private fun qrCheck(qrData: String?) {

        firebaseAuth = FirebaseAuth.getInstance()
        val userId = firebaseAuth.currentUser?.uid

        val docRef = qrData?.let { db.collection("user").document(it) }
        docRef?.get()
            ?.addOnSuccessListener { document ->
                if (document != null) {

                    val dname= document.getString("name")
                    val dimage = document.getString("userImage")

                    name.text = dname
                    Glide.with(this)
                        .load(dimage) // dimageUrl is the URL of the image
                        .into(profileImage)
                    Toast.makeText(this, "Data Found", Toast.LENGTH_SHORT).show()
                    Log.d(TAG, "DocumentSnapshot data: ${document.data}")
                }
            }
            ?.addOnFailureListener { exception ->
                Toast.makeText(this, "Data Not Found", Toast.LENGTH_SHORT).show()
                Log.d(TAG, "get failed with ", exception)
            }
        }
    }


