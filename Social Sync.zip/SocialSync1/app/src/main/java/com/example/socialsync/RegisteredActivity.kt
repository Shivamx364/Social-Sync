package com.example.socialsync

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.socialsync.databinding.ActivityRegisteredBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class RegisteredActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisteredBinding
    private lateinit var cButton: Button


    private lateinit var storageRef: StorageReference
    private lateinit var firebaseFirestore: FirebaseFirestore
    private lateinit var dbref : DatabaseReference
    private lateinit var eventRecyclerview : RecyclerView
    private  lateinit var Recycleview_created_event:Recycleview_created_event
    private lateinit var registeredEventData : ArrayList<EventRegisteredData>
    private var db = FirebaseFirestore.getInstance()
    val userId = FirebaseAuth.getInstance().currentUser?.uid
    var rEvent =""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registered)
        binding = ActivityRegisteredBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        cButton=binding.btnCreatedEventR



        binding.backToHome.setOnClickListener {
            Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@RegisteredActivity, MainActivity::class.java)
            startActivity(intent)
        }
        eventRecyclerview = findViewById(R.id.recycle_view_registered_event)
        val layoutManager : RecyclerView.LayoutManager = GridLayoutManager(this,2)
        eventRecyclerview!!.layoutManager = LinearLayoutManager(this)
        eventRecyclerview.setHasFixedSize(true)
        registeredEventData = arrayListOf<EventRegisteredData>()

        cButton.setOnClickListener {
            val intent =
                Intent(this@RegisteredActivity, AllEventActivity::class.java)
            startActivity(intent)
        }
        getUserData()

    }

    @SuppressLint("SuspiciousIndentation")
    private fun getUserData() {

        db.collection("Register Event")
            .whereEqualTo("Event User", userId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {

                    var rEventName = document.getString("Register Event Name")
                    eventShow(rEventName)


                }
            }.addOnFailureListener {
                Toast.makeText(
                    this,
                    "Something went wrong..",
                    Toast.LENGTH_SHORT
                ).show()
            }


    }

    private fun eventShow(rEventName: String?) {
        storageRef = FirebaseStorage.getInstance().reference.child("EventImage")
        firebaseFirestore = FirebaseFirestore.getInstance()
        binding.recycleViewRegisteredEvent.setHasFixedSize(true)
        binding.recycleViewRegisteredEvent.layoutManager = LinearLayoutManager(this)

        db.collection("Events")
            .whereEqualTo("EventName", rEventName)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val imageUrl = document.getString("Event Image")
                    val eventName = document.getString("EventName")
                    val eventOwner = document.getString("Event Owner")

                    Log.d("Events d", "$eventName")

                        Log.d("Events u", "$eventName")

                        if (imageUrl != null && eventName != null ) {
                            registeredEventData.add(EventRegisteredData(imageUrl, eventName))
                        }

                }
                binding.recycleViewRegisteredEvent.adapter = Recycleview_registered_event(registeredEventData,this)
            }
            .addOnFailureListener { exception ->
                // Handle failure
                Log.e("Firestore", "Error getting documents: ", exception)
            }
    }


    fun onItemClick(position: Int, eventName: String?) {
        // Handle item click here, for example:
        val clickedItem = registeredEventData[position]
        Log.d("On Click Events Parameter", "$eventName")

        val peventName = eventName // Replace this with the actual event name

        Toast.makeText(this, "Event Details", Toast.LENGTH_SHORT).show()

        // Start a new activity or fragment here
        val intent = Intent(this@RegisteredActivity, EventDetailsh::class.java)
        intent.putExtra("eventName", peventName)

        startActivity(intent)

    }
}