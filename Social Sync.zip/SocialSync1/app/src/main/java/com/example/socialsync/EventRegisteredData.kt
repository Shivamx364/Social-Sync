package com.example.socialsync

data class EventRegisteredData(
    val imageUrl: String ?=null,
    val eventName: String ?= null
)
